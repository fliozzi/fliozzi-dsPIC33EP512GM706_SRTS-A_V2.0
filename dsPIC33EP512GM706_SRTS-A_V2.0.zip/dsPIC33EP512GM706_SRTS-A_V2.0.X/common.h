/* 
 * File:   common.h
 * Author: Fernando
 *
 * Created on May 9, 2017, 11:14 AM
 */

#ifndef COMMON_H
#define	COMMON_H

extern uint8_t hr, min, sec;
volatile extern uint32_t count;

volatile extern int32_t QEIpos;
volatile extern uint8_t QEIposF;


#endif	/* COMMON_H */

